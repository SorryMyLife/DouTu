java -jar DouTu.jar
